package se.otaino2.breakoutgame.model;

import android.graphics.Color;

public class Background extends Entity {
    public Background(int width, int height) {
        super(0,0, width, height, Color.WHITE);
    }
}
