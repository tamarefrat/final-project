android-breakout-game
=====================

Solution for a school project. Nothing interesting for anyone, really...
